#include<stdio.h>
#include<unistd.h>
#include <fcntl.h> // for file mode
#include"fun.h"

int cnt = 0;

void Accept_movie(mov_t *m)
{   
    printf("Add Movie Details : \n");
    printf("Enter movie name  :   ");
    scanf("%s",m->name);
    printf("Movie Start       :");
    scanf("%s",m->star);
    printf("Movie Genre       : ");
    scanf("%s",m->genre);
    printf("Enter Release date: ");
    scanf("%d%d%d",&m->dt.dd,&m->dt.mm,&m->dt.yy);
    printf("Enter Rating      :");
    scanf("%f",&m->rating);
}

void display(mov_t *m)
{
    printf("--------------------------\n");
    printf("Movie Id        : %d \n",m->id);
    printf("Movie Name      : %s \n",m->name);
    printf("Movie SuperStar : %s \n",m->star);
    printf("Movie Genre     : %s \n",m->genre);
    printf("Relesdate  Date : %d-%d-%d\n",m->dt.dd,m->dt.mm,m->dt.yy);
    printf("Movie Rating    : %f \n",m->rating);
}

void add_movie(void)
{
    mov_t m1;
    int fd;
    fd = open(movi ,O_WRONLY | O_CREAT | O_APPEND,0777);
    if(fd < 0)
    {
        perror("File Not Open \n");
        _exit(2);
    }

    Accept_movie(&m1);
    m1.id = cnt;

    int ret = write(fd,&m1,sizeof(m1));
    if(ret != 0)
    {
        printf("Movie Added..\n");
        cnt++;
    }
    close(fd);
}


void display_movie(void)
{
    mov_t m1;
    int fd , ret;
    fd = open(movi ,O_RDONLY | O_APPEND);
    if(fd < 0)
    {
        perror("File Not Open \n");
        _exit(2);
    }

    while( (ret = read(fd,&m1,sizeof(m1))) > 0   )
    {
        display(&m1);
    }
    
    close(fd);
}



void edit_movie(void)
{
    mov_t m1;
    int fd;
    fd = open(movi ,O_RDWR );
    if(fd < 0)
    {
        perror("File Not Open \n");
        _exit(2);
    }

    int id,ret;
    float re;
    printf("Enter Id to Edit  : ");
    scanf("%d",&id);

    while( (ret = read(fd,&m1,sizeof(m1))) > 0 )
    {
        printf("Test \n");
        display(&m1);
        if(m1.id == id)
        {
            printf("Give New Rating : ");
            scanf("%f",&re);
            m1.rating = re ;
            lseek(fd, -1 * sizeof(m1),SEEK_CUR);
            write(fd,&m1,sizeof(m1));
            break;
        }
    }
    printf("Rating Edited \n");
    close(fd);
}



void Delete_movie(void)
{
    mov_t m1,m2;
    int fd;
    fd = open(movi ,O_RDWR );
    if(fd < 0)
    {
        perror("File Not Open \n");
        _exit(2);
    }
    int f_size = lseek(fd,0,SEEK_END);
    lseek(fd,0,SEEK_SET);

    int id,ret;
    float re;
    printf("Enter Id to Delete  : ");
    scanf("%d",&id);

    while( (ret = read(fd,&m1,sizeof(m1))) > 0 )
    {
        if(m1.id == id)
        {
            read(fd,&m2,sizeof(m2));
            lseek(fd, -2 * sizeof(m1),SEEK_CUR);
            write(fd,&m2,sizeof(m1));
            lseek(fd, 1 * sizeof(m1),SEEK_CUR);
        }
    }

    ftruncate(fd, f_size-sizeof(m1));
    
    printf("Rating Edited \n");
    close(fd);
}



















