
#define movi "movie.db"

typedef struct date
{
    int dd ,mm ,yy;
}date_t;

typedef struct movie
{
    int id;
    char name[20];
    char star[30];
    char genre[30];
    date_t dt;
    float rating;
}mov_t;

void Accept_movie(mov_t *m);
void add_movie(void);

void display_movie(void);
void display(mov_t *m);

void edit_movie(void);
void Delete_movie(void);