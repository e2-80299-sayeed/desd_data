#include<stdio.h>
#include<unistd.h>
#include <fcntl.h> // for file mode
#include"fun.h"

int main()
{
    int choice;
    do
    {
        write(1,"\n0.Exit \n1.Write Movie\n2.Diplay Movie \n3.Delete Movie \n4.Edit Movie\n",69);
        scanf("%d",&choice);

        switch (choice)
        {
            case 1:printf("Add Movie \n");
                   add_movie();
                break;
            case 2:printf("Display All Movie \n");
                   display_movie();
                break; 
            case 3:printf("Delete Movie \n");
                   Delete_movie();
                break; 
            case 4:printf("Edit Movie \n"); 
                    edit_movie();
                    break;     
            
            default:printf("Invalid Choice..\n");
                break;
        }
       
    } while (choice != 0 );
    
    return 0;
}